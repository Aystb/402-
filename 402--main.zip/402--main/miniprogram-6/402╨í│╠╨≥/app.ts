// app.ts
App({
  globalData: {
    username: "",
    password: "password",
    bumen: "",
    position: "",
    id: "123456",
    identification:"前往认证",
style:"width: 220rpx; background: linear-gradient(180deg, #2EB7F2 0%, #35BAF2 0%, #F0FBFF 131%);",
group:"",
    reserveData: "",
    beginTime: "",
    overTime: "",
    reserveDiscribe:"",

  },
  // onLaunch() {
  //   // 展示本地存储能力
  //   const logs = wx.getStorageSync('logs') || []
  //   logs.unshift(Date.now())
  //   wx.setStorageSync('logs', logs)


  // },
})